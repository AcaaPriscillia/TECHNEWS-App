package priscillia.gulu.technews

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button

class secondActivity : AppCompatActivity() {
    private val webView:WebView? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)
        title = "Tech News"
        val webView =findViewById<WebView>(R.id.webView)
        webView?.webViewClient = WebViewClient()
        webView?.loadUrl("https://gadgets.ndtv.com")
         val webSettings = webView.settings
         webSettings?.javaScriptEnabled = true

    }

    override fun onBackPressed() {
        super.onBackPressed()
        if (webView!!.canGoBack()){
            webView.goBack()
    } else{
            super.onBackPressed()
        }

    }
}